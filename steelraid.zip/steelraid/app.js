require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

// ── DATA FILES ─────────────────────────────────────────────────────────────
const DATA_DIR = path.join(__dirname, 'data');
const APPS_FILE = path.join(DATA_DIR, 'applicants.json');
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const STORE_FILE = path.join(DATA_DIR, 'store.json');

function ensureData() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

  if (!fs.existsSync(APPS_FILE)) fs.writeFileSync(APPS_FILE, '[]');

  if (!fs.existsSync(CONFIG_FILE)) {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify({
      siteName: process.env.SITE_NAME || 'SteelRaid SMP',
      logoText: 'SR',
      logoUrl: '/images/qirsqvblxdwfyvuigzq6.png',
      serverIp: process.env.SERVER_IP || 'play.steelraid.qzz.io',
      discordUrl: process.env.DISCORD_URL || 'https://dsc.gg/steelraid',
      storeUrl: process.env.STORE_URL || 'https://store.steelraid.qzz.io',
      donateUrl: process.env.DONATE_URL || 'https://store.steelraid.qzz.io/donate',
      mapUrl: process.env.MAP_URL || 'https://map.steelraid.qzz.io',
      fraction: 'NETWORK',
      heroTitle: 'STEELRAID SMP ☻',
      heroDesc: 'The ultimate Minecraft network forged in steel and shadow. Choose your realm. Command your fate.',
    }, null, 2));
  }

  if (!fs.existsSync(STORE_FILE)) {
    fs.writeFileSync(STORE_FILE, JSON.stringify({
      categories: [
        { id: 'cat1', name: 'Ranks', icon: '👑', description: 'Exclusive rank upgrades for the network' },
        { id: 'cat2', name: 'Keys & Crates', icon: '🗝️', description: 'Vote keys, legendary crates and more' },
        { id: 'cat3', name: 'Boosters', icon: '⚡', description: 'XP, money and drop rate boosters' },
        { id: 'cat4', name: 'Cosmetics', icon: '💎', description: 'Trails, pets, and particle effects' },
      ],
      packages: [
        { id: 'pkg1', catId: 'cat1', name: 'VIP', price: '₹199', description: 'Basic VIP rank with exclusive perks', color: '#9966ff', featured: false },
        { id: 'pkg2', catId: 'cat1', name: 'VIP+', price: '₹399', description: 'Enhanced VIP with bonus commands', color: '#cc44ff', featured: true },
        { id: 'pkg3', catId: 'cat1', name: 'Elite', price: '₹699', description: 'Elite rank with full command access', color: '#ff44aa', featured: false },
        { id: 'pkg4', catId: 'cat2', name: 'Vote Key Bundle', price: '₹99', description: '10 vote keys for instant rewards', color: '#44ccff', featured: false },
        { id: 'pkg5', catId: 'cat2', name: 'Legendary Crate x5', price: '₹249', description: 'Five legendary crates with rare drops', color: '#ffaa00', featured: true },
        { id: 'pkg6', catId: 'cat3', name: 'XP Booster 7D', price: '₹149', description: '2x XP for 7 days across all realms', color: '#00ff88', featured: false },
      ]
    }, null, 2));
  }
}
ensureData();

// ── HELPERS ────────────────────────────────────────────────────────────────
global.loadApps = () => { try { return JSON.parse(fs.readFileSync(APPS_FILE)); } catch { return []; } };
global.saveApps = (d) => fs.writeFileSync(APPS_FILE, JSON.stringify(d, null, 2));
global.loadConfig = () => { try { return JSON.parse(fs.readFileSync(CONFIG_FILE)); } catch { return {}; } };
global.saveConfig = (d) => fs.writeFileSync(CONFIG_FILE, JSON.stringify(d, null, 2));
global.loadStore = () => { try { return JSON.parse(fs.readFileSync(STORE_FILE)); } catch { return { categories: [], packages: [] }; } };
global.saveStore = (d) => fs.writeFileSync(STORE_FILE, JSON.stringify(d, null, 2));

// ── MIDDLEWARE ─────────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/images', express.static(path.join(__dirname, 'public/images')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'steelraid_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 8 * 60 * 60 * 1000 } // 8 hours
}));

// Inject config into every view
app.use((req, res, next) => {
  res.locals.cfg = loadConfig();
  res.locals.isAdmin = req.session.admin === true;
  next();
});

// ── ROUTES ─────────────────────────────────────────────────────────────────
app.use('/', require('./routes/main'));
app.use('/admin', require('./routes/admin'));
app.use('/api', require('./routes/api'));

// ── START ──────────────────────────────────────────────────────────────────
app.listen(PORT, HOST, () => {
  console.log(`\x1b[35m
╔══════════════════════════════════════════╗
║    STEELRAID SMP — SERVER ONLINE         ║
║    http://${HOST}:${PORT}                     ║
╚══════════════════════════════════════════╝\x1b[0m`);
});

module.exports = app;
