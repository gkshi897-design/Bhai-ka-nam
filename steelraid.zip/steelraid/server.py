"""
SteelRaid SMP — Python reference server (original)
This file is kept for reference only.
The main server is now Node.js (app.js).

To run the Node.js server:
    npm install
    npm start
"""

# Original Python server preserved below for reference.
# It used Flask/SimpleHTTPServer to serve static HTML files.
# All functionality has been migrated to Node.js + EJS.
