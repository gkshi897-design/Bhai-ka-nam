# SteelRaid SMP — Node.js Website v2.0

Full website converted from static HTML/CSS to **Node.js + EJS** with persistent JSON storage, hCaptcha, and a full admin dashboard.

---

## 📁 Project Structure

```
steelraid/
├── app.js                  ← Main entry point
├── package.json
├── .env                    ← Your config (edit this!)
├── routes/
│   ├── main.js             ← Public pages
│   ├── admin.js            ← Admin panel pages
│   └── api.js              ← REST API + hCaptcha
├── views/
│   ├── index.ejs           ← Home page
│   ├── donate.ejs          ← Donate / Store
│   ├── apply.ejs           ← Staff application (hCaptcha)
│   ├── vote.ejs            ← Vote page
│   ├── wiki.ejs            ← Wiki
│   ├── admin-login.ejs     ← Admin login
│   ├── admin-dashboard.ejs ← Full admin panel
│   └── partials/
│       ├── nav.ejs         ← Shared navbar
│       └── scripts.ejs     ← Shared JS (cursor, particles)
├── public/
│   ├── css/main.css        ← Global styles
│   └── images/             ← Logo and uploaded images
└── data/                   ← Auto-created JSON storage
    ├── applicants.json
    ├── config.json
    └── store.json
```

---

## 🚀 Setup & Run

### 1. Install Node.js
Download from https://nodejs.org (v18+ recommended)

### 2. Install dependencies
```bash
cd steelraid
npm install
```

### 3. Configure your .env
Edit `.env` and fill in:
```
ADMIN_USER=steelraidsmp@gmail.com
ADMIN_PASS=Ritikpal@212216
HCAPTCHA_SITE_KEY=your_site_key_here
HCAPTCHA_SECRET_KEY=your_secret_key_here
```

Get hCaptcha keys free at: https://www.hcaptcha.com/

### 4. Start the server
```bash
npm start
# or for development with auto-reload:
npm run dev
```

Open: http://localhost:3000

---

## 🌐 Pages

| URL | Description |
|-----|-------------|
| `/` | Home with 15 realms, live player count |
| `/donate` | Store packages — clicking any redirects to `store.steelraid.qzz.io/donate` |
| `/apply` | Staff application with hCaptcha |
| `/vote` | Vote links |
| `/wiki` | Wiki with sidebar navigation |
| `/admin/login` | Admin login |
| `/admin/dashboard` | Full admin panel |

---

## 🛡 Admin Dashboard Features

- **Overview** — live stats, recent applications
- **Applicants** — view, approve, reject, delete, export JSON
- **Store Categories** — add/edit/delete categories
- **Store Packages** — add/edit/delete packages with color & featured flag
- **Site Settings** — change server IP, URLs, fraction badge, hero text — **all live-editable**
- **Logo & Branding** — upload logo image OR paste URL, live preview, change site name

### Admin Login
```
Email: steelraidsmp@gmail.com  (set in .env)
Password: Ritikpal@212216      (set in .env)
```

---

## ⚙️ What You Can Change from Admin Dashboard

Everything! Without touching code:
- ✅ Site name
- ✅ Server IP
- ✅ Logo (upload file or URL)
- ✅ Fraction/server tag shown on homepage
- ✅ Hero title & description
- ✅ Discord, Store, Donate, Map URLs
- ✅ Store categories and packages (name, price, color, description)
- ✅ Approve/reject/delete staff applications

---

## 🔒 hCaptcha Setup

1. Go to https://www.hcaptcha.com/ and create a free account
2. Add your site (domain or localhost)
3. Copy your **Site Key** and **Secret Key**
4. Paste them in `.env`:
   ```
   HCAPTCHA_SITE_KEY=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
   HCAPTCHA_SECRET_KEY=0x...
   ```

> For local testing, the default keys `10000000-ffff-ffff-ffff-000000000001` (site) and `0x0000000000000000000000000000000000000000` (secret) work automatically.

---

## 📦 Tech Stack

- **Node.js** + **Express** — server
- **EJS** — templating
- **JSON files** — storage (no MongoDB)
- **hCaptcha** — bot protection on staff apply
- **CSS** — all styling (no framework)
- **Python** — original server.py kept for reference

---

## 🔄 Donate Redirect

Every package "Purchase" button and the "Donate Now" button redirect to:
```
https://store.steelraid.qzz.io/donate
```
This URL is configurable from Admin → Site Settings → Donate URL.
