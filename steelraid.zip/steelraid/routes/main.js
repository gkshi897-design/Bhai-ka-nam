const express = require('express');
const router = express.Router();

// ── HOME ────────────────────────────────────────────────────────────────────
router.get('/', (req, res) => {
  const cfg = loadConfig();
  res.render('index', { cfg, title: cfg.siteName + ' — The Network' });
});

// ── DONATE ─────────────────────────────────────────────────────────────────
router.get('/donate', (req, res) => {
  const cfg = loadConfig();
  const store = loadStore();
  res.render('donate', { cfg, store, title: cfg.siteName + ' — Donate' });
});

// ── VOTE ───────────────────────────────────────────────────────────────────
router.get('/vote', (req, res) => {
  const cfg = loadConfig();
  res.render('vote', { cfg, title: cfg.siteName + ' — Vote' });
});

// ── APPLY ──────────────────────────────────────────────────────────────────
router.get('/apply', (req, res) => {
  const cfg = loadConfig();
  res.render('apply', {
    cfg,
    title: cfg.siteName + ' — Staff Application',
    hcaptchaSiteKey: process.env.HCAPTCHA_SITE_KEY || '10000000-ffff-ffff-ffff-000000000001',
    error: null,
    success: false
  });
});

// ── WIKI ───────────────────────────────────────────────────────────────────
router.get('/wiki', (req, res) => {
  const cfg = loadConfig();
  res.render('wiki', { cfg, title: cfg.siteName + ' — Wiki' });
});

module.exports = router;
