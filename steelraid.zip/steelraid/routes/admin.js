const express = require('express');
const router = express.Router();

function requireAdmin(req, res, next) {
  if (req.session.admin === true) return next();
  res.redirect('/admin/login');
}

// ── ADMIN LOGIN PAGE ────────────────────────────────────────────────────────
router.get('/login', (req, res) => {
  if (req.session.admin) return res.redirect('/admin/dashboard');
  res.render('admin-login', { cfg: loadConfig(), title: 'SteelRaid — Command Center Access', error: null });
});

router.post('/login', (req, res) => {
  const { user, pass } = req.body;
  if (user === process.env.ADMIN_USER && pass === process.env.ADMIN_PASS) {
    req.session.admin = true;
    return res.redirect('/admin/dashboard');
  }
  res.render('admin-login', { cfg: loadConfig(), title: 'SteelRaid — Command Center Access', error: 'Invalid credentials' });
});

// ── ADMIN LOGOUT ────────────────────────────────────────────────────────────
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/admin/login');
});

// ── ADMIN DASHBOARD ─────────────────────────────────────────────────────────
router.get('/dashboard', requireAdmin, (req, res) => {
  const cfg = loadConfig();
  const apps = loadApps();
  const store = loadStore();
  res.render('admin-dashboard', {
    cfg,
    apps,
    store,
    title: 'SteelRaid — Command Center',
    pendingCount: apps.filter(a => a.status === 'pending').length
  });
});

module.exports = router;
