const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');

// ── MC STATUS ───────────────────────────────────────────────────────────────
router.get('/status', async (req, res) => {
  const cfg = loadConfig();
  try {
    const r = await fetch(`https://api.mcsrvstat.us/3/${cfg.serverIp}`, {
      headers: { 'User-Agent': 'SteelRaid/2.0' }
    });
    const d = await r.json();
    res.json({ online: d.online || false, players: d.players?.online || 0, max: d.players?.max || 0 });
  } catch (e) {
    res.json({ online: false, players: 0, error: e.message });
  }
});

// ── STAFF APPLY (POST with hCaptcha) ───────────────────────────────────────
router.post('/apply', async (req, res) => {
  const { legalName, age, mobile, email, address, aadhar, mcUsername, why, 'h-captcha-response': hcaptchaToken } = req.body;

  // Validate hCaptcha
  const hcSecret = process.env.HCAPTCHA_SECRET_KEY || '0x0000000000000000000000000000000000000000';
  let captchaOk = false;
  try {
    const verifyRes = await fetch('https://hcaptcha.com/siteverify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `secret=${hcSecret}&response=${hcaptchaToken}`
    });
    const verifyData = await verifyRes.json();
    captchaOk = verifyData.success === true;
  } catch (e) {
    // If hcaptcha is in test mode (site key starts with 10000000), allow it
    if (process.env.HCAPTCHA_SITE_KEY && process.env.HCAPTCHA_SITE_KEY.startsWith('10000000')) {
      captchaOk = true;
    }
  }

  if (!captchaOk) {
    return res.status(400).json({ success: false, error: 'hCaptcha verification failed. Please try again.' });
  }

  // Validate fields
  const errors = [];
  if (!legalName || legalName.trim().length < 2) errors.push('Legal name required (min 2 chars)');
  const ageN = parseInt(age);
  if (isNaN(ageN) || ageN < 13 || ageN > 99) errors.push('Age must be 13–99');
  if (!mobile || !/^[\+\d\s\-]{7,15}$/.test(mobile.trim())) errors.push('Valid mobile required');
  if (!email || !/^[^\s@]+@gmail\.com$/i.test(email.trim())) errors.push('Only @gmail.com addresses accepted');
  if (!address || address.trim().length < 10) errors.push('Full address required (min 10 chars)');
  if (!aadhar || aadhar.replace(/\s/g, '').length < 6) errors.push('Valid ID number required');
  if (!mcUsername || mcUsername.trim().length < 3) errors.push('Minecraft username required');
  if (!why || why.trim().length < 30) errors.push('Statement required (min 30 chars)');

  if (errors.length) return res.status(400).json({ success: false, errors });

  // Save
  const apps = loadApps();
  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
    legalName: legalName.trim(),
    age: String(ageN),
    mobile: mobile.trim(),
    email: email.trim(),
    address: address.trim(),
    aadhar: aadhar.trim(),
    mcUsername: mcUsername.trim(),
    why: why.trim(),
    status: 'pending',
    timestamp: new Date().toISOString(),
    ip: req.ip
  };
  apps.push(entry);
  saveApps(apps);
  console.log(`[NEW APP] ${entry.legalName} (${entry.email})`);
  res.json({ success: true, id: entry.id });
});

// ── ADMIN LOGIN (API) ───────────────────────────────────────────────────────
router.post('/admin/login', (req, res) => {
  const { user, pass } = req.body;
  if (user === process.env.ADMIN_USER && pass === process.env.ADMIN_PASS) {
    req.session.admin = true;
    res.json({ success: true });
  } else {
    setTimeout(() => res.status(401).json({ success: false, error: 'Invalid credentials' }), 500);
  }
});

// ── ADMIN LOGOUT ────────────────────────────────────────────────────────────
router.post('/admin/logout', (req, res) => {
  req.session.admin = false;
  req.session.destroy();
  res.json({ success: true });
});

// ── ADMIN: GET APPLICANTS ───────────────────────────────────────────────────
router.get('/admin/applicants', requireAdmin, (req, res) => {
  res.json({ success: true, data: loadApps() });
});

// ── ADMIN: UPDATE APPLICANT STATUS ─────────────────────────────────────────
router.post('/admin/applicants/:id/:action', requireAdmin, (req, res) => {
  const { id, action } = req.params;
  if (!['approved', 'rejected', 'pending'].includes(action)) {
    return res.status(400).json({ success: false, error: 'Invalid action' });
  }
  const apps = loadApps();
  const app = apps.find(a => a.id === id);
  if (!app) return res.status(404).json({ success: false, error: 'Not found' });
  app.status = action;
  saveApps(apps);
  res.json({ success: true, status: action });
});

// ── ADMIN: DELETE APPLICANT ─────────────────────────────────────────────────
router.delete('/admin/applicants/:id', requireAdmin, (req, res) => {
  const apps = loadApps().filter(a => a.id !== req.params.id);
  saveApps(apps);
  res.json({ success: true });
});

// ── ADMIN: GET/SAVE SITE CONFIG ─────────────────────────────────────────────
router.get('/admin/config', requireAdmin, (req, res) => {
  res.json({ success: true, data: loadConfig() });
});

router.post('/admin/config', requireAdmin, (req, res) => {
  const current = loadConfig();
  const allowed = ['siteName','logoText','logoUrl','serverIp','discordUrl','storeUrl','donateUrl','mapUrl','fraction','heroTitle','heroDesc'];
  const updated = { ...current };
  allowed.forEach(k => { if (req.body[k] !== undefined) updated[k] = req.body[k]; });
  saveConfig(updated);
  res.json({ success: true, data: updated });
});

// ── ADMIN: GET/SAVE STORE DATA ──────────────────────────────────────────────
router.get('/admin/store', requireAdmin, (req, res) => {
  res.json({ success: true, data: loadStore() });
});

router.post('/admin/store', requireAdmin, (req, res) => {
  const { categories, packages } = req.body;
  if (!Array.isArray(categories) || !Array.isArray(packages)) {
    return res.status(400).json({ success: false, error: 'Invalid data' });
  }
  saveStore({ categories, packages });
  res.json({ success: true });
});

// ── ADMIN: LOGO UPLOAD ──────────────────────────────────────────────────────
const multer = require('multer');
const path = require('path');
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../public/images/')),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `logo${ext}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (req, file, cb) => {
  if (/\.(png|jpg|jpeg|gif|webp|svg)$/i.test(file.originalname)) cb(null, true);
  else cb(new Error('Only image files allowed'));
}});

router.post('/admin/logo', requireAdmin, upload.single('logo'), (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, error: 'No file uploaded' });
  const cfg = loadConfig();
  cfg.logoUrl = `/images/${req.file.filename}`;
  saveConfig(cfg);
  res.json({ success: true, logoUrl: cfg.logoUrl });
});

function requireAdmin(req, res, next) {
  if (req.session.admin === true) return next();
  res.status(401).json({ success: false, error: 'Unauthorized' });
}

module.exports = router;
